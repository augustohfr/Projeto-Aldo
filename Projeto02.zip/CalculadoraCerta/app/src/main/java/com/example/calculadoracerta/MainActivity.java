package com.example.calculadoracerta;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {



    double resultado,n1, n2;

    EditText texto1, texto2, resultado;
    Button soma, subtracao, divisao, multiplicacao, porcentagem;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        soma      = (Button)   findViewById(R.id.som);
        subtracao    = (Button)   findViewById(R.id.sub);
        divisao     = (Button)   findViewById(R.id.div);
        multiplicacao = (Button)   findViewById(R.id.mul);
        texto1    = (EditText) findViewById(R.id.txt1);
        texto2    = (EditText) findViewById(R.id.txt2);
        resultado  = (EditText) findViewById(R.id.res);
        porcentagem = (Button)   findViewById(R.id.por);

        soma.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                n1 = Double.parseDouble(txt1.getText().toString());
                n2 = Double.parseDouble(txt2.getText().toString());

                resultado = n1+n2;
                res.setText(String.valueOf(res));
            }
        });

        subtracao.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                n1 = Double.parseDouble(txt1.getText().toString());
                n2 = Double.parseDouble(txt2.getText().toString());

                resultado = n1-n2;

                res.setText(String.valueOf(resultado));
            }
        });

        divisao.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                n1 = Double.parseDouble(txt1.getText().toString());
                n2 = Double.parseDouble(txt2.getText().toString());

                resultado = n1/n2;

                res.setText(String.valueOf(resultado));
            }
        });

        multiplicacao.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                n1 = Double.parseDouble(texto1.getText().toString());
                n2 = Double.parseDouble(texto2.getText().toString());

                resultado = n1*n2;
                res.setText(String.valueOf(resultado));
                res.setText(String.valueOf(resultado));

            }
        });


        porcentagem.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                n1 = Double.parseDouble(txt1.getText().toString());
                n2 = Double.parseDouble(txt2.getText().toString());

                resultado = n1 = n2 *0.10;
                res.setText(String.valueOf(resultado));


            }
        });

    }
}