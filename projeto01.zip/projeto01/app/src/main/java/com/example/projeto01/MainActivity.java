package com.example.projeto01;

        import android.app.Activity;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button b1 = (Button) findViewById(R.id.bt_calcular);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText consumo = (EditText) findViewById(R.id.edt_consumo);
                EditText couvert = (EditText) findViewById(R.id.edt_couvert_artistico);
                EditText dividir = (EditText) findViewById(R.id.edt_dividir);
                EditText servico = (EditText) findViewById(R.id.edt_servico);
                EditText conta = (EditText) findViewById(R.id.edt_conta_total);
                EditText valor = (EditText) findViewById(R.id.edt_valor_pessoa);


                double taxaServiço = Double.parseDouble(consumo.getText().toString())*0.10;
                double contaTotal = Double.parseDouble(couvert.getText().toString()+ Double.parseDouble(consumo.getText().toString())+ taxaServiço;
                double contaPessoa = contaTotal / Double.parseDouble(div.getText().toString());
                servico.setText((int)taxaServiço);
            }
        });

    }
}